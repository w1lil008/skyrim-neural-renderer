# v0.1.0-prototype — Skyrim native depth and motion

Experimental portable tester package for Windows x64, vanilla Skyrim SE and
2560×1440 borderless gameplay. Download the **tester ZIP attached below**;
GitHub's automatic source archives do not substitute for this packaged asset.

The tester ZIP includes the compiled native-input integration, a preserved
Present fallback, portable launcher/recovery scripts, source and validation
notes. Testers supply their own game and matching DXL/NVIDIA runtime DLLs using
the included setup script. The ZIP does not include Skyrim or proprietary neural
runtime dependencies. Read README.md before launching.

The native-input Helgen test recorded at least 9,851 neural calls, zero
failed/skipped calls and a clean Quit to Desktop; the tester confirmed F8 worked.
Eight actual gameplay captures supported depth geometry and native motion
correspondence. Controlled motion substitution changed neural output. Depth
reaches the API, but its effect on output remains unproven.

The included native build has a later history-reset repair verified in a
synthetic scene, not another gameplay run. The portable launcher's deployment
and recovery checks were tested separately; its complete first-run workflow
still needs testing on another PC.

Only the exact executable/Bink hashes listed in config/requirements.json are
accepted. Only an RTX 4060 Ti was used for the recorded gameplay test. The sampled
full neural pass measured about 17.59 ms at 1440p; this is not a frame-rate or
total added-cost guarantee. Long sessions, other scenes, HUD/transparency, resize,
an earlier shutdown error and exact depth/display alignment remain unresolved.
ENB support is outside this pre-release.

Please report GPU/driver, Windows/game version, F8 behavior, Quit outcome and the
latest summary.json. Review local paths and captured gameplay images before
sharing logs. Keep True NR Layers at 1.
