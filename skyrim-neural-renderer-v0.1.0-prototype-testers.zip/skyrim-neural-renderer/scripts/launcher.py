"""Portable, reversible tester launcher. Python 3.11+, Windows x64, stdlib only."""
import argparse
import contextlib
import ctypes
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import stat
import struct
import subprocess
import sys
import time
import uuid

ROOT = Path(__file__).resolve().parents[1]
DEPLOY_NAMES = ('bink2w64.dll', 'DXL-core.dll', 'DXL-ReShade.dll', 'nvngx_dlssnr.dll')
CONFLICTS = ('dxgi.dll', 'd3d11.dll', 'dinput8.dll', 'version.dll', 'winmm.dll',
             'RE_DLSS5_Core.dll', 'enbseries.ini', 'enblocal.ini')


def digest(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def load(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))


def save(path, value):
    path = Path(path)
    temporary = path.with_name(path.name + '.new')
    reject_links(path)
    reject_links(temporary)
    with temporary.open('w', encoding='utf-8', newline='\n') as stream:
        json.dump(value, stream, indent=2)
        stream.flush()
        os.fsync(stream.fileno())
    os.replace(temporary, path)


def reject_links(path):
    """Check lexical ancestors before resolve() can hide a junction."""
    path = Path(os.path.abspath(path))
    for current in (path, *path.parents):
        try:
            info = current.lstat()
        except FileNotFoundError:
            continue
        if stat.S_ISLNK(info.st_mode) or getattr(info, 'st_file_attributes', 0) & 0x400:
            raise RuntimeError(f'Links/junctions are unsupported: {current}')
    return path


def safe_member(base, value):
    path = reject_links(Path(base) / value)
    if not path.resolve().is_relative_to(Path(base).resolve()):
        raise RuntimeError('Manifest path escapes its package folder')
    return path


def assert_ascii_paths(root, game=None):
    paths = [Path(root)] + ([Path(game)] if game else [])
    for path in paths:
        if not str(path).isascii():
            raise RuntimeError('This prototype needs an ASCII-only extraction/game path')
        parts = [part.lower() for part in path.parts]
        if any(parts[index:index+2] == ['steamapps', 'common'] for index in range(len(parts)-1)):
            raise RuntimeError('Extract/copy outside Steam library installation folders')
    if len(str(root)) > 125 or (game and len(str(game)) > 210):
        raise RuntimeError('Extract to a shorter path, e.g. C:\\SkyrimNR')


def verified_files(root):
    manifest = load(root / 'PACKAGE_MANIFEST.json')
    for entry in manifest['files']:
        path = safe_member(root, entry['path'])
        if not path.is_file() or digest(path) != entry['sha256']:
            raise RuntimeError(f'Package file missing or changed: {entry["path"]}')
    return manifest


def resolve_game(root, supplied=None):
    test_root = reject_links(root / 'TestGame').resolve()
    if supplied:
        game = reject_links(Path(supplied)).resolve()
    else:
        # Do not traverse links while discovering a tester's copied installation.
        choices = []
        for directory, folders, files in os.walk(test_root, followlinks=False):
            folders[:] = [name for name in folders if not linked(Path(directory) / name)]
            if 'SkyrimSE.exe' in files:
                choices.append(Path(directory))
        if len(choices) != 1:
            raise RuntimeError('Copy one vanilla Skyrim SE installation into TestGame, then run again')
        game = reject_links(choices[0]).resolve()
    if game == test_root or not game.is_relative_to(test_root):
        raise RuntimeError('GameDirectory must be a separate copied installation below this package\'s TestGame folder')
    assert_ascii_paths(root, game)
    # Check the whole copy: the AE content installer can write Data files too.
    for directory, folders, files in os.walk(game, followlinks=False):
        for name in folders + files:
            path = Path(directory) / name
            reject_links(path)
            if path.is_file() and path.stat().st_nlink > 1:
                raise RuntimeError(f'Hard-linked game files are unsupported: {path.name}')
    return game


def linked(path):
    info = path.lstat()
    return stat.S_ISLNK(info.st_mode) or bool(getattr(info, 'st_file_attributes', 0) & 0x400)


def check_game(game, requirements):
    for name, expected in requirements['game'].items():
        path = game / name
        if not path.is_file() or digest(path) != expected:
            raise RuntimeError(f'Unsupported or modified {name}; this release requires the exact validated game/Bink build (see README)')
    for name in ('Skyrim_Default.ini', 'Skyrim/SkyrimPrefs.ini', 'steam_api64.dll'):
        if not (game / name).is_file():
            raise RuntimeError(f'Incomplete copied installation: {name}')
    if not (game / 'Data').is_dir():
        raise RuntimeError('Copied installation has no Data directory')
    conflicts = [name for name in CONFLICTS if (game / name).exists()]
    if conflicts:
        raise RuntimeError('Use a vanilla copy without other injectors: ' + ', '.join(conflicts))
    for name in DEPLOY_NAMES:
        path = game / name
        if path.exists() and (not path.is_file() or getattr(path.stat(), 'st_file_attributes', 0) & 1):
            raise RuntimeError(f'Deployment destination is not a writable regular file: {name}')


def dependency_files(root, requirements):
    result = {}
    for name, expected in requirements['runtime'].items():
        path = safe_member(root / 'runtime', name)
        if not path.is_file() or digest(path) != expected:
            raise RuntimeError(f'Missing/mismatched {name}. Run Setup-Runtime.ps1 with your matching, lawfully obtained dependency package')
        result[name] = path
    return result


def import_dependencies(root, source, requirements):
    source = reject_links(source).resolve()
    if not source.is_dir():
        raise RuntimeError('Choose an extracted dependency folder')
    found, count = {}, 0
    for directory, folders, files in os.walk(source, followlinks=False):
        folders[:] = [name for name in folders if not linked(Path(directory) / name)]
        for name in files:
            count += 1
            if count > 20000:
                raise RuntimeError('Choose a smaller extracted package folder')
            key = next((k for k in requirements['runtime'] if k.lower() == name.lower()), None)
            if key:
                path = reject_links(Path(directory) / name)
                if path.is_file() and digest(path) == requirements['runtime'][key]:
                    found[key] = path
    if not found:
        raise RuntimeError('No matching runtime DLLs found; hashes/versions are listed in config/requirements.json')
    target = reject_links(root / 'runtime')
    target.mkdir(exist_ok=True)
    for name, source_path in found.items():
        destination = safe_member(target, name)
        if source_path != destination:
            atomic_copy(source_path, destination)
        print('Imported:', name)
    missing = [name for name, expected in requirements['runtime'].items()
               if not (target / name).is_file() or digest(target / name) != expected]
    print('Still needed: ' + ', '.join(missing) if missing else 'All runtime dependencies match.')


def atomic_copy(source, destination):
    destination = Path(destination)
    reject_links(destination)
    temporary = destination.with_name('.' + destination.name + '.snr-' + uuid.uuid4().hex + '.tmp')
    try:
        shutil.copy2(source, temporary)
        os.replace(temporary, destination)
    finally:
        if temporary.exists():
            temporary.unlink()


def game_running():
    from ctypes import wintypes
    class ProcessEntry(ctypes.Structure):
        _fields_ = [('dwSize', wintypes.DWORD), ('cntUsage', wintypes.DWORD),
                    ('th32ProcessID', wintypes.DWORD), ('th32DefaultHeapID', ctypes.c_size_t),
                    ('th32ModuleID', wintypes.DWORD), ('cntThreads', wintypes.DWORD),
                    ('th32ParentProcessID', wintypes.DWORD), ('pcPriClassBase', wintypes.LONG),
                    ('dwFlags', wintypes.DWORD), ('szExeFile', wintypes.WCHAR * 260)]
    kernel = ctypes.WinDLL('kernel32', use_last_error=True)
    kernel.CreateToolhelp32Snapshot.argtypes = [wintypes.DWORD, wintypes.DWORD]
    kernel.CreateToolhelp32Snapshot.restype = wintypes.HANDLE
    for name in ('Process32FirstW', 'Process32NextW'):
        function = getattr(kernel, name)
        function.argtypes = [wintypes.HANDLE, ctypes.POINTER(ProcessEntry)]
        function.restype = wintypes.BOOL
    kernel.CloseHandle.argtypes = [wintypes.HANDLE]
    handle = kernel.CreateToolhelp32Snapshot(2, 0)
    if handle == ctypes.c_void_p(-1).value:
        raise ctypes.WinError(ctypes.get_last_error())
    entry = ProcessEntry()
    entry.dwSize = ctypes.sizeof(entry)
    try:
        found = kernel.Process32FirstW(handle, ctypes.byref(entry))
        while found:
            if entry.szExeFile.lower() == 'skyrimse.exe':
                return True
            found = kernel.Process32NextW(handle, ctypes.byref(entry))
        if ctypes.get_last_error() != 18:  # ERROR_NO_MORE_FILES
            raise ctypes.WinError(ctypes.get_last_error())
        return False
    finally:
        kernel.CloseHandle(handle)


@contextlib.contextmanager
def package_lock(root):
    import msvcrt
    path = safe_member(root, 'launcher.lock')
    with path.open('a+b') as stream:
        if stream.tell() == 0:
            stream.write(b'0')
            stream.flush()
        stream.seek(0)
        try:
            msvcrt.locking(stream.fileno(), msvcrt.LK_NBLCK, 1)
        except OSError as error:
            raise RuntimeError('Another launcher is using this package') from error
        try:
            yield
        finally:
            stream.seek(0)
            msvcrt.locking(stream.fileno(), msvcrt.LK_UNLCK, 1)


def prepare_deployment(game, run, sources):
    backups = run / 'backups'
    backups.mkdir()
    items = []
    for name in DEPLOY_NAMES:
        destination = reject_links(game / name)
        backup = backups / name if destination.exists() else None
        if backup:
            shutil.copy2(destination, backup)
        items.append(dict(name=name, original_sha256=digest(backup) if backup else None,
                          installed_sha256=digest(sources[name])))
    record = dict(schema=1, game=str(game), restored=False, items=items)
    save(run / 'deployment.json', record)
    return record


def restore_deployment(root, run):
    record = load(run / 'deployment.json')
    game = resolve_game(root, record['game'])
    items = record['items']
    if len(items) != 4 or {item['name'] for item in items} != set(DEPLOY_NAMES):
        raise RuntimeError('Unexpected deployment manifest; restore refused')
    plans = []
    # Validate EVERY backup and destination before modifying any of them.
    for item in items:
        name = item['name']
        destination = reject_links(game / name)
        backup = safe_member(run / 'backups', name) if item['original_sha256'] else None
        if backup and (not backup.is_file() or digest(backup) != item['original_sha256']):
            raise RuntimeError(f'Backup damaged: {name}; keep this run for recovery')
        current = digest(destination) if destination.is_file() else None
        if destination.exists() and not destination.is_file():
            raise RuntimeError(f'Destination is not a file: {name}')
        if current == item['original_sha256']:
            continue
        if current not in (None, item['installed_sha256']):
            raise RuntimeError(f'{name} changed independently; automatic restore refused. Backup is in {run / "backups"}')
        plans.append((destination, backup))
    for destination, backup in plans:
        if backup:
            atomic_copy(backup, destination)
        elif destination.exists():
            destination.unlink()
    for item in items:
        path = game / item['name']
        actual = digest(path) if path.is_file() else None
        if actual != item['original_sha256']:
            raise RuntimeError(f'Restore verification failed: {item["name"]}')
    record['restored'] = True
    save(run / 'deployment.json', record)
    active = root / 'active-run.json'
    if active.exists():
        active.unlink()
    print('All four deployed files restored and verified.')


def recover(root):
    active = root / 'active-run.json'
    if not active.exists():
        print('No interrupted deployment to recover.')
        return
    if game_running():
        raise RuntimeError('Close Skyrim before recovery')
    run = safe_member(root / 'logs', load(active)['run'])
    restore_deployment(root, run)


def replace_setting(text, key, value, section='Display'):
    pattern = r'(?mi)^' + re.escape(key) + r'\s*=.*$'
    if re.search(pattern, text):
        return re.sub(pattern, key + '=' + str(value), text)
    section_pattern = r'(?mi)^\[' + re.escape(section) + r'\]\s*$'
    if re.search(section_pattern, text):
        return re.sub(section_pattern, '[' + section + ']\n' + key + '=' + str(value), text, count=1)
    return text + '\n[' + section + ']\n' + key + '=' + str(value) + '\n'


def prepare_profile(root, game, run):
    profile = safe_member(root, 'profile')
    if profile.exists():
        for directory, folders, files in os.walk(profile, followlinks=False):
            for name in folders + files:
                path = Path(directory) / name
                reject_links(path)
                if path.is_file() and path.stat().st_nlink > 1:
                    raise RuntimeError('Profile contains a hard link; use a regular isolated profile')
    for suffix in ('Documents/My Games/Skyrim Special Edition/Saves',
                   'LocalAppData/Skyrim Special Edition', 'AppData', 'Temp'):
        safe_member(profile, suffix).mkdir(parents=True, exist_ok=True)
    docs = profile / 'Documents/My Games/Skyrim Special Edition'
    ini = docs / 'Skyrim.ini'
    if not ini.exists():
        ini.write_text((game / 'Skyrim_Default.ini').read_text(encoding='utf-8-sig')
                       .replace('sIntroSequence=BGS_Logo.bik', 'sIntroSequence='), encoding='utf-8')
    prefs = docs / 'SkyrimPrefs.ini'
    text = (prefs if prefs.exists() else game / 'Skyrim/SkyrimPrefs.ini').read_text(encoding='utf-8-sig')
    for key, value in (('bFull Screen', 0), ('bBorderless', 1), ('iSize W', 2560),
                       ('iSize H', 1440), ('iVSyncPresentInterval', 1), ('bUseTAA', 1)):
        text = replace_setting(text, key, value)
    prefs.write_text(text, encoding='utf-8')
    plugins = profile / 'LocalAppData/Skyrim Special Edition/plugins.txt'
    if not plugins.exists():
        plugins.write_text('', encoding='utf-8')
    config = load(root / 'config/core.json')
    config_path = safe_member(profile, 'LocalAppData/DXL/profiles/skyrimse.exe.json')
    config_path.parent.mkdir(parents=True, exist_ok=True)
    save(config_path, config)
    save(run / 'core_settings.json', config)
    return profile


def child_environment(game, run, profile, mode, requirements):
    # Drop inherited research/fixture flags so they cannot corrupt tester inputs.
    env = {key: value for key, value in os.environ.items()
           if not key.upper().startswith(('SKYRIM_PROBE_', 'SKYRIM_TEMPORAL_'))}
    env.update(SKYRIM_PROBE_EXPECTED_EXE=str(game / 'SkyrimSE.exe'),
               SKYRIM_PROBE_LOG=str(run / 'probe.log'), SKYRIM_PROBE_OUTPUT=str(run),
               SKYRIM_PROBE_PROFILE=str(profile), SKYRIM_PROBE_CAPTURE='0',
               SKYRIM_PROBE_CORE='1', SKYRIM_PROBE_INPUTS='0', SKYRIM_PROBE_SIDECAR='0',
               SKYRIM_PROBE_CORE_PATH=str(game / 'DXL-core.dll'),
               SKYRIM_PROBE_ORIGINAL_DLL=str(run / 'backups/bink2w64.dll'),
               SKYRIM_PROBE_CORE_DIAGNOSTICS='0', SKYRIM_PROBE_CORE_DELAY_MS='0',
               SKYRIM_PROBE_EXCLUDE_RTSS='1', USERPROFILE=str(profile),
               APPDATA=str(profile / 'AppData'), LOCALAPPDATA=str(profile / 'LocalAppData'),
               TEMP=str(profile / 'Temp'), TMP=str(profile / 'Temp'),
               SteamAppId='489830', SteamGameId='489830')
    if mode == 'native':
        native = requirements['native']
        env.update(SKYRIM_TEMPORAL_MODE='depth-motion',
                   SKYRIM_TEMPORAL_VALIDATED_SHADER=native['taa_shader'],
                   SKYRIM_TEMPORAL_VALIDATED_DEPTH='1', SKYRIM_TEMPORAL_VALIDATED_MOTION='1',
                   SKYRIM_TEMPORAL_VALIDATED_WIDTH='2560', SKYRIM_TEMPORAL_VALIDATED_HEIGHT='1440',
                   SKYRIM_TEMPORAL_VALIDATED_DEPTH_FORMAT=str(native['source_depth_format']),
                   SKYRIM_TEMPORAL_VALIDATED_MOTION_FORMAT=str(native['source_motion_format']))
    return env


def core_status(pid, run):
    from ctypes import wintypes
    kernel = ctypes.WinDLL('kernel32', use_last_error=True)
    kernel.OpenFileMappingW.argtypes = [wintypes.DWORD, wintypes.BOOL, wintypes.LPCWSTR]
    kernel.OpenFileMappingW.restype = wintypes.HANDLE
    kernel.MapViewOfFile.argtypes = [wintypes.HANDLE, wintypes.DWORD, wintypes.DWORD, wintypes.DWORD, ctypes.c_size_t]
    kernel.MapViewOfFile.restype = ctypes.c_void_p
    kernel.UnmapViewOfFile.argtypes = [ctypes.c_void_p]
    kernel.CloseHandle.argtypes = [wintypes.HANDLE]
    handle = kernel.OpenFileMappingW(4, False, 'Local\\DXL.Status.' + str(pid))
    if not handle:
        return
    address = None
    try:
        address = kernel.MapViewOfFile(handle, 4, 0, 0, 0)
        if not address:
            return
        data = ctypes.string_at(address, 1024)
        words = struct.unpack_from('<16I', data)
        if words[:2] != (0x35534C44, 13) or words[2] % 2 or ctypes.c_uint32.from_address(address + 8).value != words[2]:
            return
        record = dict(time=time.time(), master_enabled=bool(struct.unpack_from('<I', data, 252)[0]),
                      calls=struct.unpack_from('<Q', data, 104)[0], failures=struct.unpack_from('<Q', data, 112)[0],
                      skipped=struct.unpack_from('<Q', data, 144)[0],
                      nr_gpu_ms=struct.unpack_from('<f', data, 240)[0], optical_gpu_ms=struct.unpack_from('<f', data, 580)[0],
                      render_size=struct.unpack_from('<2I', data, 64), output_size=struct.unpack_from('<2I', data, 72),
                      core_native_depth=words[9], core_native_motion=words[10], route=struct.unpack_from('<I', data, 572)[0])
        with (run / 'core_status.jsonl').open('a', encoding='utf-8') as stream:
            stream.write(json.dumps(record) + '\n')
    finally:
        if address:
            kernel.UnmapViewOfFile(address)
        kernel.CloseHandle(handle)


def summarize(run):
    summary = dict(note='Parameter reads do not prove neural use of depth; numerical checks are sampled.')
    for filename in ('core_status.jsonl', 'temporal.jsonl'):
        path = run / filename
        if not path.exists():
            continue
        rows = []
        with path.open(encoding='utf-8', errors='replace') as stream:
            for line in stream:
                try:
                    rows.append(json.loads(line))
                except ValueError:
                    pass
        summary[filename] = dict(samples=len(rows), last=rows[-1] if rows else None)
        if filename == 'temporal.jsonl':
            summary['native'] = {key: sum(bool(row.get(key)) for row in rows) for key in
                                 ('depth_numeric_valid', 'depth_nonzero', 'motion_numeric_valid',
                                  'motion_nonzero', 'depth_parameter_read', 'motion_parameter_read')}
    save(run / 'summary.json', summary)


def launch(root, game, mode, runtime, requirements):
    run_name = time.strftime('%Y%m%d-%H%M%S') + '-' + mode + '-' + uuid.uuid4().hex[:6]
    run = safe_member(root / 'logs', run_name)
    run.mkdir(parents=True)
    sources = dict(runtime, **{'bink2w64.dll': root / ('bin/native' if mode == 'native' else 'bin/present') / 'bink2w64.dll'})
    profile = prepare_profile(root, game, run)
    prepare_deployment(game, run, sources)
    save(root / 'active-run.json', dict(run=run_name))  # durable recovery journal BEFORE deployment
    process = None
    try:
        for name, source in sources.items():
            atomic_copy(source, game / name)
        print('Launching copied Skyrim. F8: effect; F9: panel. Quit to Desktop when finished.', flush=True)
        print('Leave this launcher open. Logs:', run, flush=True)
        started = time.monotonic()
        with (run / 'stdout.txt').open('w') as out, (run / 'stderr.txt').open('w') as err:
            process = subprocess.Popen([str(game / 'SkyrimSE.exe')], cwd=game,
                                       env=child_environment(game, run, profile, mode, requirements), stdout=out, stderr=err)
            save(run / 'process.json', dict(pid=process.pid, executable=str(game / 'SkyrimSE.exe')))
            fatal = False
            while process.poll() is None:
                try:
                    core_status(process.pid, run)
                except Exception as error:
                    with (run / 'monitor-errors.txt').open('a', encoding='utf-8') as stream:
                        stream.write(str(error) + '\n')
                log = run / 'probe.log'
                if log.exists() and 'FATAL' in log.read_text(errors='replace'):
                    fatal = True
                    print('Isolation/runtime startup failed. Closing this test; inspect probe.log.', flush=True)
                    process.terminate()
                    break
                time.sleep(1)
            process.wait(timeout=15)
        save(run / 'result.json', dict(exit_code=process.returncode, startup_failed=fatal,
                                      elapsed_seconds=round(time.monotonic() - started, 2), mode=mode))
        summarize(run)
        return 0 if process.returncode == 0 and not fatal else 1
    finally:
        if process and process.poll() is None:
            process.terminate()
            process.wait(timeout=15)
        # If shutdown cannot be confirmed, the journal remains for later recovery.
        restore_deployment(root, run)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--game-directory', type=Path)
    parser.add_argument('--mode', choices=('native', 'present'), default='native')
    parser.add_argument('--check', action='store_true', help='Read-only preflight; does not launch or deploy')
    parser.add_argument('--recover', action='store_true')
    parser.add_argument('--import-dependencies', type=Path)
    args = parser.parse_args()
    if os.name != 'nt' or struct.calcsize('P') != 8 or sys.version_info < (3, 11):
        raise RuntimeError('Use Windows x64 and 64-bit Python 3.11 or later')
    reject_links(ROOT)
    assert_ascii_paths(ROOT)
    verified_files(ROOT)
    requirements = load(ROOT / 'config/requirements.json')
    with package_lock(ROOT):
        if args.recover:
            recover(ROOT)
            return 0
        if args.import_dependencies:
            import_dependencies(ROOT, args.import_dependencies, requirements)
            return 0
        if (ROOT / 'active-run.json').exists():
            raise RuntimeError('Interrupted deployment found. Close Skyrim, then run Launch.ps1 -Recover')
        if game_running():
            raise RuntimeError('Close the currently running Skyrim before this test')
        game = resolve_game(ROOT, args.game_directory)
        check_game(game, requirements)
        runtime = dependency_files(ROOT, requirements)
        print('Preflight passed:', game)
        if args.check:
            return 0
        return launch(ROOT, game, args.mode, runtime, requirements)


if __name__ == '__main__':
    try:
        sys.exit(main())
    except (Exception, KeyboardInterrupt) as error:
        print('STOP:', str(error) or 'Interrupted', file=sys.stderr)
        print('If files remain deployed, close Skyrim and run Launch.ps1 -Recover.', file=sys.stderr)
        sys.exit(2)
