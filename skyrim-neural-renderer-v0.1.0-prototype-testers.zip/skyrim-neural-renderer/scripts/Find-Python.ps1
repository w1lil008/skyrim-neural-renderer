function Find-RendererPython([string]$Requested) {
    $taskCandidates = @()
    if ($Requested) {
        $taskCandidates += @{Path=$Requested;Prefix=@()}
    } else {
        foreach ($taskName in @('py.exe','python.exe','python3.exe')) {
            $taskCommand = Get-Command $taskName -ErrorAction SilentlyContinue
            if ($taskCommand) {
                $taskCandidates += @{Path=$taskCommand.Source;Prefix=$(if ($taskName -eq 'py.exe') {@('-3')} else {@()})}
            }
        }
    }
    foreach ($taskCandidate in $taskCandidates) {
        $taskCallArguments = @($taskCandidate.Prefix) + @('-c','import sys,struct; sys.exit(0 if sys.version_info >= (3,11) and struct.calcsize("P")==8 else 1)')
        & $taskCandidate.Path @taskCallArguments 2>$null | Out-Null
        if ($LASTEXITCODE -eq 0) { return $taskCandidate }
    }
    throw 'Install 64-bit Python 3.11+ from python.org, or pass -Python with its executable path.'
}
