Dependencies are not included. Import lawfully obtained matching copies using
Setup-Runtime.cmd (you can run it once per extracted dependency folder).
Required files and SHA-256 hashes are in config\requirements.json:
  DXL-core.dll
  DXL-ReShade.dll
  nvngx_dlssnr.dll
The old v0.56 RE_DLSS5_Core.dll is not a substitute for the pinned DXL v0.7 core.
