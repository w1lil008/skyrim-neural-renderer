# Skyrim Neural Renderer — v0.1.0-prototype

Experimental Windows x64 tester package. Includes the compiled Skyrim integration,
the preserved Present fallback and their source. **This is a pre-release.**

Native depth and motion feeding worked in a short Helgen test. F8 worked and Quit
to Desktop completed normally. Motion substitution changed neural output in a
controlled test; depth's effect on neural output remains unproven. See
[validation](docs/VALIDATION.md) for the exact scope and remaining issues.

## Requirements

- Windows x64 and **64-bit Python 3.11 or later**. Install from
  [python.org](https://www.python.org/downloads/windows/) if needed. No Python
  packages are required.
- Your own complete, vanilla Skyrim SE installation, copied independently for
  testing. The tested executable reports **1.7.104.0**; exact executable and Bink
  hashes must match [requirements.json](config/requirements.json). Other game
  versions are refused, including in Present mode.
- A 2560×1440 display and TAA. The launcher sets 1440p borderless windowed and
  TAA in its isolated profile. Other resolutions/HDR are outside this release.
- A compatible NVIDIA RTX GPU/driver and matching, lawfully obtained copies of
  **DXL-core.dll, DXL-ReShade.dll and nvngx_dlssnr.dll**. These separate runtime
  dependencies are **not included**. Only the RTX 4060 Ti has been tested here.
  This is an integration prototype, not an official NVIDIA release.
- Steam running with ownership of Skyrim SE. The launcher runs the copied EXE;
  it does not download the game or bypass Steam.

The DXL dependency used here is v0.7 from
[LCPD15/DXL](https://github.com/LCPD15/DXL), source commit
`8644a875e61a9ecb8379f78ce9fd3ef3bc4853a4`. Obtain its binaries from the author's
distribution. The older v0.56 RE_DLSS5 core is not interchangeable. The neural DLL
must match the hash in requirements.json; this package provides no NVIDIA
runtime download or redistribution grant.

## First run

1. Extract the ZIP to a short, ASCII-only path, for example `C:\SkyrimNR`.
2. Copy your vanilla Skyrim folder into `TestGame\Skyrim Special Edition`.
   It must contain `SkyrimSE.exe`, the original `bink2w64.dll`, `Data`, and normal
   game files. Use ordinary file copies, not links. Keep your Steam installation
   where it is. Remove other injectors from this **test copy** before using it.
3. Run `Setup-Runtime.cmd`. Enter the folder containing your extracted matching
   dependencies. If DXL and the neural DLL are in different folders, run setup
   once for each folder. Setup only copies hash-matching DLLs into `runtime`.
4. Run `Launch.cmd`. It discovers the single copied game below `TestGame`, checks
   versions and dependencies, and launches it. Leave the launcher window open.
5. Start a new game and test the moving Helgen carriage. **F8** toggles the effect;
   **F9** opens the DXL panel. Use **Quit to Desktop** when finished.

For a read-only game preflight, or to select the preserved Present build, use
PowerShell from the extracted folder:

```powershell
.\Launch.ps1 -Check
.\Launch.ps1 -Mode present
```

Pass `-Python 'C:\path\to\python.exe'` if Python cannot be found automatically.
Pass `-GameDirectory` only when your copy is in a different subfolder **inside
this package's TestGame folder**. Steam library paths are not accepted.

## Backups, saves and recovery

The launcher backs up every existing deployment destination before replacing it:
`bink2w64.dll`, `DXL-core.dll`, `DXL-ReShade.dll`, `nvngx_dlssnr.dll`. On exit it
restores originals and removes newly staged files, then verifies their hashes.
Logs and backups stay in `logs\<run>`. The original compiled DLLs can retain
compiler/debug build-path metadata; no personal saves or raw development logs
are included in the ZIP.

Saves and settings live in this package's persistent `profile` folder. Your normal
My Games saves/settings are not imported. Each launch resets DXL options to the
single-feature tested configuration. Leave **True NR Layers at 1** during a run.
The copied game's AE installer may refresh content in the test copy; these game
Data changes are not undone. The launcher does not alter your Steam installation.

If the launcher was forcibly closed or the PC restarted, close Skyrim and run:

```powershell
.\Launch.ps1 -Recover
```

A pending journal blocks another launch until recovery. Recovery refuses altered
backups or independently changed deployed files; retain `logs` and inspect the
recorded backups if manual recovery is needed. Do not move the extracted package
while a deployment is active. After normal verified restoration it can be moved.

## Reading the results

Inspect the newest `logs\<run>` folder:

- `summary.json`: sampled validity/non-zero checks and parameter-read counts.
- `temporal.jsonl`: frame/shader/source IDs, resolution/formats, numerical checks,
  resources supplied/read, calls/failures and capture/conversion GPU timings.
- `core_status.jsonl`: F8 master state, neural calls/failures/skips and full neural
  GPU timing, separate from optical-flow timing.
- `probe.log`: initialization, adapter, fallback and route/reset messages.
- `result.json`, `deployment.json`: process exit and restoration status.

The core panel's Depth/Motion labels may still show zero because they describe
its internal path. Use the external-input logs above to assess this integration.
Parameter acceptance alone does not prove meaningful model use. Input checks are
sampled, and matching this executable does not establish correctness in every
scene. The native build automatically captures up to eight diagnostic frame
buffers; allow roughly 1 GB of free space per run. Logs/captures can contain your
local paths and gameplay images—review them before sharing.

## Limits

The native DLL includes a history-reset repair tested in a synthetic scene after
the successful gameplay test; that repair has not been retested in Skyrim.
Depth influence, exact subpixel display alignment, an earlier intermittent Quit
error, longer sessions, other scenes, HUD/transparency and resize remain open.
ENB and other injectors are outside this release. No universal GPU compatibility
or frame-rate gain is claimed.

For code rebuilding, see [source notes](source/README.md). Third-party notices are
in [THIRD_PARTY_NOTICES.md](THIRD_PARTY_NOTICES.md). No open-source license has yet
been selected for the project's own code; this ZIP is for the private tester
evaluation described here, not a grant to republish vendor dependencies.
