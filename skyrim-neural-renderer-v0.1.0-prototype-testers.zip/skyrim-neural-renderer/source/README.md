# Source and rebuilding

`src` is the current native-input implementation, including the fixture-verified
history-reset repair. `present-src` is extracted from the preserved known-good
checkpoint and corresponds to the included Present fallback. The launch scripts
and Python module at the package root are the portable packaging implementation.

`generated/native` and `generated/present` contain only the export-name header,
forwarding assembly and module definition produced from the validated Bink
export table. No game code or original Bink binary is distributed. This table is
specific to the Bink hash in requirements.json.

Use Zig 0.14.1 for Windows x64, obtained separately from
[ziglang.org](https://ziglang.org/download/). From PowerShell:

```powershell
.\Build.ps1 -Zig 'C:\tools\zig\zig.exe'
.\Build.ps1 -Zig 'C:\tools\zig\zig.exe' -Present
```

Output goes to `source\build\native` or `source\build\present`. Build paths and
debug metadata can change binary hashes. Rebuilding does not automatically
replace the shipped DLLs or their manifest. Review and regenerate an intentional
new package before distributing changed binaries.

MinHook source and its license are included. DXL source is a separate project,
pinned in THIRD_PARTY_NOTICES.md. No compiler, NVIDIA runtime, Windows SDK/game
binary, personal saves, raw run logs or copied game is included.

The project's own code has no selected open-source license yet. Third-party
license texts continue to apply to their respective components.
