param([Parameter(Mandatory=$true)][string]$Zig,[switch]$Present)
$ErrorActionPreference = 'Stop'
$taskRoot = $PSScriptRoot
$taskKind = if ($Present) {'present'} else {'native'}
$taskSource = Join-Path $taskRoot $(if ($Present) {'present-src'} else {'src'})
$taskGenerated = Join-Path $taskRoot ('generated\'+$taskKind)
$taskBuild = Join-Path $taskRoot ('build\'+$taskKind)
$taskMinHook = Join-Path $taskRoot 'third_party\minhook'
New-Item -ItemType Directory -Path $taskBuild -Force | Out-Null
$env:ZIG_GLOBAL_CACHE_DIR = Join-Path $taskBuild 'zig-global-cache'
$env:ZIG_LOCAL_CACHE_DIR = Join-Path $taskBuild 'zig-local-cache'
$taskObjects = @()
foreach ($taskUnit in @('buffer','hook','trampoline','hde\hde64')) {
    $taskObject = Join-Path $taskBuild (($taskUnit -replace '\\','-')+'.o')
    & $Zig cc -target x86_64-windows-gnu -O2 -c (Join-Path $taskMinHook ('src\'+$taskUnit+'.c')) -o $taskObject
    if ($LASTEXITCODE) { throw 'MinHook build failed' }
    $taskObjects += $taskObject
}
$taskUnits = @('probe.cpp','sidecar.cpp')
if (!$Present) { $taskUnits += @('temporal.cpp','temporal_gpu_watch.cpp','temporal_d3d11_slots.cpp','temporal_sensitivity.cpp') }
$taskSources = @($taskUnits | ForEach-Object {Join-Path $taskSource $_})
& $Zig c++ -target x86_64-windows-gnu -std=c++17 -O2 -g -shared @taskSources (Join-Path $taskGenerated 'proxy_exports.S') (Join-Path $taskGenerated 'bink2w64.def') @taskObjects -I $taskGenerated -I (Join-Path $taskMinHook 'include') -o (Join-Path $taskBuild 'bink2w64.dll') -ld3d12 -ldxguid -luuid -lole32 -ladvapi32 -ld3dcompiler_47
if ($LASTEXITCODE) { throw 'Renderer build failed' }
Get-FileHash -LiteralPath (Join-Path $taskBuild 'bink2w64.dll') -Algorithm SHA256
