# Third-party components

The integration DLLs statically include MinHook/HDE, copyright Tsuda Kageyu and
Vyacheslav Patkov. Their BSD-style terms are included in
[licenses/MinHook-LICENSE.txt](licenses/MinHook-LICENSE.txt), with source in
`source/third_party/minhook`.

DXL, copyright LCPD15, is an external dependency licensed AGPL-3.0, with separate
component terms. Its source revision for this experiment is
[`8644a875e61a9ecb8379f78ce9fd3ef3bc4853a4`](https://github.com/LCPD15/DXL/tree/8644a875e61a9ecb8379f78ce9fd3ef3bc4853a4).
DXL-core.dll and DXL-ReShade.dll are not redistributed in this ZIP. Obtain them
from the author with their own license/notices. DXL includes or uses components
such as ReShade and WebView2; retain the notices from that distribution.

NVIDIA's nvngx_dlssnr.dll is an external proprietary runtime dependency and is
not redistributed here. This project's source and MinHook license do not grant
rights to redistribute it. NVIDIA product terms apply to the separately obtained
runtime.

Skyrim, Bink and Steam game files are not included. Testers supply their own
licensed game copy. Project names identify the software being tested and do not
imply endorsement by NVIDIA or Bethesda.
