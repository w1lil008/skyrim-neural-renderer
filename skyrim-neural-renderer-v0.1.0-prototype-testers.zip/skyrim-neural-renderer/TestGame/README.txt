Copy your owned, vanilla Skyrim Special Edition installation into a subfolder here,
using ordinary independent copies, for example:
  TestGame\Skyrim Special Edition\SkyrimSE.exe
Do not move your Steam installation. Do not use links, junctions or hard links.
The game itself is not included in this release.
