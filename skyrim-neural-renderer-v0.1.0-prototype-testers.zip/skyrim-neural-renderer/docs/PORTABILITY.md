# Portable package checks — 7 October 2026

This package changes deployment and paths; the included renderer DLLs retain
their preserved binary fingerprints. It does not claim another gameplay test.

The Windows launcher tests exercise independent game-copy discovery, read-only
game checks, unsupported executable/injector rejection, short ASCII paths,
Steam installation path rejection, hard-link/junction rejection, package
integrity, concurrent launch exclusion, hash-gated dependency imports, isolated
persistent profiles, inherited research-flag removal, partial deployment
recovery, refusal of damaged backups or independently changed files, refusal of
recovery while Skyrim runs, failed process-start restoration, and a completed
stub process with a recorded exit result. These tests use tiny synthetic files;
they do not start Skyrim or modify the copied or real installations.

Both native and preserved Present source rebuilds completed with the portable
Build.ps1 instructions and Zig 0.14.1. Rebuilt files stay in source/build and are
excluded from the asset; the packaged binaries are the original checkpointed
files, not these rebuild outputs. PowerShell parsing and explicit Python
discovery passed. The ZIP's file hashes and corruption check passed.

The launcher checks exact executable/Bink/runtime hashes. Its native profile
uses the reviewed TAA shader fingerprint, 2560×1440 resolution and source formats
at runtime. A fresh exact-version copy does not prove scene validity on another
PC. An end-to-end portable game launch, GPU/driver compatibility on another PC,
and gameplay after the later Reset repair remain untested.
