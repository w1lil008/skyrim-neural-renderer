param(
    [string]$GameDirectory,
    [ValidateSet('native','present')][string]$Mode='native',
    [string]$Python,
    [switch]$Check,
    [switch]$Recover
)
$ErrorActionPreference = 'Stop'
. (Join-Path $PSScriptRoot 'scripts\Find-Python.ps1')
$taskRuntime = Find-RendererPython $Python
$taskArguments = @((Join-Path $PSScriptRoot 'scripts\launcher.py'),'--mode',$Mode)
if ($GameDirectory) { $taskArguments += @('--game-directory',$GameDirectory) }
if ($Check) { $taskArguments += '--check' }
if ($Recover) { $taskArguments += '--recover' }
$taskCallArguments = @($taskRuntime.Prefix) + $taskArguments
& $taskRuntime.Path @taskCallArguments
exit $LASTEXITCODE
