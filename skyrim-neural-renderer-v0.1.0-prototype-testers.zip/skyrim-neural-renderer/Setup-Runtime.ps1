param([string]$PackageDirectory,[string]$Python)
$ErrorActionPreference = 'Stop'
. (Join-Path $PSScriptRoot 'scripts\Find-Python.ps1')
$taskRuntime = Find-RendererPython $Python
if (!$PackageDirectory) { $PackageDirectory = Read-Host 'Path to your extracted DXL/neural dependency package (no quotes)' }
$taskArguments = @((Join-Path $PSScriptRoot 'scripts\launcher.py'),'--import-dependencies',$PackageDirectory)
$taskCallArguments = @($taskRuntime.Prefix) + $taskArguments
& $taskRuntime.Path @taskCallArguments
exit $LASTEXITCODE
